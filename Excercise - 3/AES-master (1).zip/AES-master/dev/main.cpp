#include <iostream>
#include "../src/AES.h"

int main()
{
  std::cout << "Aes dev" << std::endl;
  return 0;
}
